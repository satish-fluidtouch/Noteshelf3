//
//  DAVResponseItem.m
//  DAVKit
//
//  Copyright Matt Rajca 2010. All rights reserved.
//

#import "DAVResponseItem.h"

@implementation DAVResponseItem

@synthesize href, modificationDate, contentLength, contentType,isCollection,displayName;
@synthesize creationDate;
@synthesize fileAttributes = attributes;

- (NSString *)description {
    NSString *isACollection = [NSString stringWithFormat:isCollection ? @"YES" : @"NO"];
    return [NSString stringWithFormat:@"href = %@; modificationDate = %@; contentLength = %lld; "
                                      @"contentType = %@; creationDate = %@; attributes = %@; isCollection = %@; displayname = %@",
                                      href, modificationDate, contentLength, contentType,
                                      creationDate, attributes, isACollection, displayName];
}

@end
